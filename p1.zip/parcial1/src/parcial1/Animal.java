
package parcial1;

import java.util.Objects;


public abstract class Animal {
   
    private String codigo;
    private String nombre;
    private double costoMantenimiento;
    private EstadoSalud salud;
    
    public Animal(String codigo, String nombre, EstadoSalud salud){
        Objects.requireNonNull(nombre);
        Objects.requireNonNull(salud);
        Objects.requireNonNull(codigo);
        if (nombre.isBlank() || codigo.isBlank()) {
            throw new IllegalArgumentException("El nombre y el codigo no pueden estar vacios");
        }
        this.codigo = codigo;
        this.nombre = nombre;
        this.salud = salud;
    }
    
    protected void setMantenimiento(double m){
        validarMantenimiento(m);
        this.costoMantenimiento = m;
    }
    
    
    private void validarMantenimiento(double m) {
        if (m <= 0) {
            throw new IllegalStateException();
        }
    }
    
    protected void validarPositivo(double m, String msg) {
        if (m < 0 ){
            throw new IllegalArgumentException(msg);
        }
    }
    
    protected abstract double calcularMantenimiento();
    
    public String getNombre(){
        return this.nombre;
    }
    
    public String getCodigo(){
        return this.codigo;
    }
    
    public EstadoSalud getSalud() {
        return this.salud;
    }
    
    public double getMantenimiento() {
        return this.costoMantenimiento;
    }
    
    public void setSalud(EstadoSalud nuevaSalud) {
        Objects.requireNonNull(nuevaSalud);
        this.salud = nuevaSalud;
    }
    
    @Override
    public boolean equals(Object o) {
        boolean bool = false;
        if (o instanceof Animal a) {
            bool = (this.codigo.equals(a.codigo) && this.nombre.equals(a.nombre));
        }
        return bool;
    }
}
