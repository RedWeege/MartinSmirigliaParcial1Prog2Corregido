
package parcial1;

public class AnimalDuplicadoException extends Exception {

    public AnimalDuplicadoException(String mensaje) {
        super(mensaje);
    };
    
    public AnimalDuplicadoException() {
        super("El animal ya existe en el centro");
    }
}
