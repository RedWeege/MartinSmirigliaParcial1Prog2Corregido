package parcial1;

public class Ave extends Animal implements Rehabilitable, Liberable{
    private int envargadura;
    public static final int MODIFICADOR_MANTENIMIENTO = 2;
    
    public Ave(String codigo, String nombre, EstadoSalud salud, int envargadura) {
        super(codigo, nombre, salud);
        super.validarPositivo(envargadura, "La envargadura no puede ser negativa");
        this.envargadura = envargadura;
        double mantenimiento = calcularMantenimiento();
        super.setMantenimiento(mantenimiento);
    }
    
    @Override
    public void rehabilitar() {
        System.out.println("El ave codigo " + super.getCodigo() + " y nombre " + super.getNombre() + " esta siendo rehabilitada");
    }
    
    @Override
    public void liberar() {
        System.out.println("Liberando al ave " + super.getNombre() + " con codigo " + super.getCodigo());
    }
    
    @Override
    protected double calcularMantenimiento() {
        return this.envargadura * MODIFICADOR_MANTENIMIENTO;
    }
    
    public int getEnvargadura() {
        return this.envargadura;
    }
}
