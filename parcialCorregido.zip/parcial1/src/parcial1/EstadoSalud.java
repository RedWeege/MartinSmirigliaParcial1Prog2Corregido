/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1;

/**
 *
 * @author marti
 */
public enum EstadoSalud {
    CRITICO,
    EN_RECUPERACION,
    ESTABLE
}
