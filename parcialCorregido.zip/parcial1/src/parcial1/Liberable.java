package parcial1;

public interface Liberable {
    public void liberar();
}
