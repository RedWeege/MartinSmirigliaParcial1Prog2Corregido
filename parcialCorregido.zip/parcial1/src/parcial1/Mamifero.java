
package parcial1;

public class Mamifero extends Animal implements Rehabilitable{
    private double peso;
    public static final int MODIFICADOR_MANTENIMIENTO = 10;
    
    public Mamifero(String codigo, String nombre, EstadoSalud salud, double peso) {
        super(codigo, nombre, salud);
        super.validarPositivo(peso, "El peso no puede ser negativo");
        this.peso = peso;
        double mantenimiento = calcularMantenimiento();
        super.setMantenimiento(mantenimiento);
    }
    
    @Override
    protected double calcularMantenimiento() {
        return this.peso * MODIFICADOR_MANTENIMIENTO;
    }
    
    @Override
    public void rehabilitar() {
        System.out.println("El mamifero codigo " + super.getCodigo() + " y nombre " + super.getNombre() + " esta siendo rehabilitado");
    }
    
    public double getPeso() {
        return this.peso;
    }
}
