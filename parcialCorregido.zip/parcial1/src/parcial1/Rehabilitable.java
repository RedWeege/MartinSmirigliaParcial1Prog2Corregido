package parcial1;

public interface Rehabilitable {
    public void rehabilitar();
}
