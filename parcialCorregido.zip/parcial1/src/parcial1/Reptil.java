
package parcial1;

/**
 *
 * @author marti
 */
public class Reptil extends Animal implements Liberable{
    private int longitud;
    public static final int MODIFICADOR_MANTENIMIENTO = 15;
    
    public Reptil(String codigo, String nombre, EstadoSalud salud, int longitud) {
        super(codigo, nombre, salud);
        super.validarPositivo(longitud, "La longitud no puede ser negativa");
        this.longitud = longitud;
        double mantenimiento = calcularMantenimiento();
        super.setMantenimiento(mantenimiento);
    }
    
    @Override
    public void liberar() {
        System.out.println("El reptil codigo " + super.getCodigo() + " y nombre " + super.getNombre() + " es libre");
    }
    
    @Override
    protected double calcularMantenimiento() {
        return this.longitud + MODIFICADOR_MANTENIMIENTO;
    }
    
    public int getLongitud(){
        return this.longitud;
    }
}
